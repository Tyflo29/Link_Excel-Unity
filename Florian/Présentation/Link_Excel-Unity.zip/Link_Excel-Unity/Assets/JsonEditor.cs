using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName ="Excel", fileName ="Export_Excel")]
public class JsonEditor : ScriptableObject
{
    public void Truc() 
    {
        var x = JsonUtility.ToJson(mc);
        Debug.Log(x);
    }
    public TextAsset myFile;
    public MyClass mc;

    void Start()
    {
        Truc();
    }
    public void ImportFromJson() 
    {
        mc = JsonUtility.FromJson<MyClass>(myFile.text);
    }
}
