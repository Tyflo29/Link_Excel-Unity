using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class MyClass
{
    public MyStructDe[] ms;
}

[System.Serializable]
public struct MyStructDe
{
    public int i;
    public int y;
}